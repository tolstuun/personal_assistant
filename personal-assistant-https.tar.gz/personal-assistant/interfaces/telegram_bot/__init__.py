"""Telegram bot interface."""

from interfaces.telegram_bot.bot import TelegramBot, BotConfig

__all__ = ["TelegramBot", "BotConfig"]
